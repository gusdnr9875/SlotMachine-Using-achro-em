#ifndef SIGN_H
#define SIGN_H

#include <qapplication.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qwidget.h>
#include <qmessagebox.h>
#include <qlayout.h>

#define kor(str) QString::fromLocal8Bit(str)

class SignSlot : public QWidget{
Q_OBJECT

public:
SignSlot();

private:
QVBoxLayout *vbox;
QPushButton *quit;
QPushButton *some_act;
QLabel *msg;

public slots:
void Some_Action();
};

#endif // SIGN_H
